package com.example.service;

public class Invoice {

}
