package com.example.Enum;

public enum PaymentType {
	
	CREDITCARD,DEBITCARD,UPI

}