package com.example.Enum;

public enum JobType {
	
	EXPERIENCED,INTERNSHIP

}
