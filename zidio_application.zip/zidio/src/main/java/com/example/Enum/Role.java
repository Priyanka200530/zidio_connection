package com.example.Enum;

public enum Role {
 
	STUDENT,RECRUITER,ADMIN
}
