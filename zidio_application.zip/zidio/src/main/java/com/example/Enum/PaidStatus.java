package com.example.Enum;

public enum PaidStatus {
ACTIVE,EXPIRED,CNCELLED
}