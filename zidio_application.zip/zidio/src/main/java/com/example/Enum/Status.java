package com.example.Enum;

public enum Status {
	APPLIED,SHORTLIST,REJECTED,SELECTED

}
