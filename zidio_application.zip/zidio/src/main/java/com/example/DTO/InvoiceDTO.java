package com.example.DTO;

public class InvoiceDTO {

}
