package com.example.DTO;

public class StudentDTO {
	
	
	public Long id;
	public String name;
	public String email;
	public String phone;
	public String qualification;
	public String resumeleURL;

	
public StudentDTO(Long id2, String name2, String email2, String phone2, String qualifiaction, String resumeURL) {
	this.id=id;
	this.name=name;
	this.email=email;
	this.phone=phone;
	this.qualification=qualification;
	this.resumeleURL=resumeURL;
		
	}
}

