package com.example.DTO;

public @interface AllArgsConstructor {

}
