package com.example.DTO;
 
import com.example.Enum.Role;

public class RegisterRequest {
 
	public String name;
	public String email;
	public String password;
	public Role role;
}
