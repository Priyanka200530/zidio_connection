package com.example.zidio;

public class AnalyticsServiceApplication {

}
