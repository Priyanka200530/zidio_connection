package com.example.zidio;

public class UserPaymentStatusServiceApplication {

}
