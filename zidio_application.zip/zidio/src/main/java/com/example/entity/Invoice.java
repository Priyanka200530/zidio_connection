package com.example.entity;

public class Invoice {

}
