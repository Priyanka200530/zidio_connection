package com.example.repositoty;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Enum.Role;
import com.example.entity.SystemUser;

@Repository

public interface SystemUserRepository extends JpaRepository {
	SystemUser findByEmail(String email);
	SystemUser findByRole(Role role);

}
