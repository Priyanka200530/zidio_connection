package com.example.repositoty;

import java.util.Collection;

import com.example.DTO.SubscriptionPlanDTO;
import com.example.entity.SubscriptionPlan;

public interface SubscriptionPlanRepository {

	SubscriptionPlan save(SubscriptionPlan subcription);

	Collection<SubscriptionPlanDTO> findAll();

	

}
