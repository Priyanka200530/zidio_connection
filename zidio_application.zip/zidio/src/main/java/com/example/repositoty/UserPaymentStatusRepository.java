package com.example.repositoty;

import java.util.Optional;

import com.example.DTO.UserPaymentStatusDTO;
import com.example.entity.UserPaymentStatus;

public interface UserPaymentStatusRepository {

	Optional<UserPaymentStatusDTO> findByUserId(Long id);

	UserPaymentStatus save(UserPaymentStatus paymentStatus);

}
