package com.example.repositoty;

public interface InvoiceRepository {

}
